def apply_theme(app):
    app.setStyle("Fusion")  # Use Fusion style for better customization

    # Arabic font
    font = app.font()
    font.setFamily("Arial")  # Use a font that supports Arabic
    font.setPointSize(12)
    app.setFont(font)

    # Dark theme example
    dark_palette = app.palette()
    dark_palette.setColor(dark_palette.Window, "#2E3440")
    dark_palette.setColor(dark_palette.WindowText, "#ECEFF4")
    dark_palette.setColor(dark_palette.Base, "#3B4252")
    dark_palette.setColor(dark_palette.AlternateBase, "#4C566A")
    dark_palette.setColor(dark_palette.ToolTipBase, "#ECEFF4")
    dark_palette.setColor(dark_palette.ToolTipText, "#2E3440")
    dark_palette.setColor(dark_palette.Text, "#ECEFF4")
    dark_palette.setColor(dark_palette.Button, "#434C5E")
    dark_palette.setColor(dark_palette.ButtonText, "#ECEFF4")
    dark_palette.setColor(dark_palette.BrightText, "#BF616A")
    dark_palette.setColor(dark_palette.Highlight, "#5E81AC")
    dark_palette.setColor(dark_palette.HighlightedText, "#ECEFF4")
    app.setPalette(dark_palette)